
import mongoose from 'mongoose';
import Customization from '../src/models/Customization';
import Flavor from '../src/models/Flavor';
import Size from '../src/models/Size';
import OrderService from '../src/services/OrderService';

describe('OrderService', () => {
  beforeAll(async () => {
    await mongoose.connect('mongodb://localhost:27017/test', {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
  });

  afterAll(async () => {
    await mongoose.disconnect();
  });

  beforeEach(async () => {
    await Size.deleteMany({});
    await Flavor.deleteMany({});
    await Customization.deleteMany({});
  });

  it('should calculate pizza details correctly', async () => {
    await Size.create({ name: 'Média', price: 30.30, preparationTime: 20 });
    await Flavor.create({ name: 'Calabresa', additionalTime: 0 });
    await Customization.create({ name: 'Extra bacon', price: 3.00, additionalTime: 0 });

    const pizzaData = {
      size: 'Média',
      flavor: 'Calabresa',
      customizations: ['Extra bacon'],
    };

    const result = await OrderService.calculatePizzaDetails(pizzaData);

    expect(result.price).toBe(33.30);
    expect(result.preparationTime).toBe(20);
  });

  it('should create an order with multiple pizzas correctly', async () => {
    await Size.create({ name: 'Média', price: 30.30, preparationTime: 20 });
    await Flavor.create({ name: 'Calabresa', additionalTime: 0 });
    await Flavor.create({ name: 'Portuguesa', additionalTime: 5 });
    await Customization.create({ name: 'Extra bacon', price: 3.00, additionalTime: 0 });

    const pizzas = [
      { size: 'Média', flavor: 'Calabresa', customizations: ['Extra bacon'] },
      { size: 'Média', flavor: 'Portuguesa', customizations: [] },
    ];

    const order = await OrderService.createOrder(pizzas);

    expect(order.totalValue).toBe(63.60);
    expect(order.totalPreparationTime).toBe(25); // Max of the two preparation times
  });
});
